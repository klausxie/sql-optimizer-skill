# SQL Optimize Report: run_1445e6e47c9b

## Executive Decision
- Release Readiness: `CONDITIONAL_GO`
- Verdict: `PARTIAL`
- Scope: SQL units `4`, proposals `4`
- Delivery Snapshot: patches `0`, applicable `0`, blocked sql `1`
- Perf Evidence: improved `0`, not improved `3`

## Top Risks
- `VALIDATE_SECURITY_DOLLAR_SUBSTITUTION` (`degradable`): count `1`, impacted sql `1`

## Delivery Status
- preflight: `DONE`
- scan: `DONE` (attempts `1`)
- optimize: `DONE` (attempts `4`)
- validate: `DONE` (attempts `4`)
- patch_generate: `DONE` (attempts `4`)
- report: `DONE`

## Change Portfolio
| SQL Key | Status | Source | Perf | Patch Applicable | Patch Decision |
|---|---|---|---|---|---|
| `demo.user.listUsers#v1` | `PASS` | `llm` | `not-improved` | `false` | `PATCH_NOT_APPLICABLE` |
| `demo.user.listUsersSorted#v1` | `PASS` | `llm` | `not-improved` | `false` | `PATCH_NOT_APPLICABLE` |
| `demo.user.findUsersByStatusRecent#v1` | `PASS` | `llm` | `not-improved` | `false` | `PATCH_NOT_APPLICABLE` |
| `demo.user.findUsers#v1` | `NEED_MORE_PARAMS` | `rule` | `unknown` | `n/a` | `PATCH_CONFLICT_NO_CLEAR_WINNER` |

## Proposal Insights
| SQL Key | Verdict | Issues | LLM Candidates |
|---|---|---|---|
| `demo.user.listUsers#v1` | `NOOP` | `FULL_SCAN_RISK` | `3` |
| `demo.user.listUsersSorted#v1` | `CAN_IMPROVE` | `SELECT_STAR,FULL_SCAN_RISK` | `3` |
| `demo.user.findUsersByStatusRecent#v1` | `NOOP` | `none` | `1` |
| `demo.user.findUsers#v1` | `CAN_IMPROVE` | `DOLLAR_SUBSTITUTION` | `0` |

## Technical Evidence
- `demo.user.listUsers#v1`: row-check `MATCH`, cost `10.8` -> `10.8`
  evidence: `/Users/klaus/Desktop/sql-optimizer/tests/fixtures/project/runs/run_1445e6e47c9b/evidence/demo.user.listUsers#v1/candidate_1/equivalence.json`
- `demo.user.listUsersSorted#v1`: row-check `MATCH`, cost `13.53` -> `13.53`
  evidence: `/Users/klaus/Desktop/sql-optimizer/tests/fixtures/project/runs/run_1445e6e47c9b/evidence/demo.user.listUsersSorted#v1/candidate_1/equivalence.json`
- `demo.user.findUsersByStatusRecent#v1`: row-check `MATCH`, cost `0.02` -> `0.02`
  evidence: `/Users/klaus/Desktop/sql-optimizer/tests/fixtures/project/runs/run_1445e6e47c9b/evidence/demo.user.findUsersByStatusRecent#v1/candidate_1/equivalence.json`

## Action Plan (Next 24h)
- Platform: resume run: `PYTHONPATH=python python3 scripts/sqlopt_cli.py resume --run-id run_1445e6e47c9b`
- Backend: remove ${} dynamic SQL: `rg -n "\$\{" src/main/resources/**/*.xml`

## Appendix
- report.json: `run_1445e6e47c9b/report.json`
- proposals: `run_1445e6e47c9b/proposals/optimization.proposals.jsonl`
- acceptance: `run_1445e6e47c9b/acceptance/acceptance.results.jsonl`
- patches: `run_1445e6e47c9b/patches/patch.results.jsonl`
- failures: `run_1445e6e47c9b/ops/failures.jsonl`
