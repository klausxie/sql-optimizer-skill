# SQL Optimize Summary: run_1445e6e47c9b

- Verdict: `PARTIAL`
- Release Readiness: `CONDITIONAL_GO`
- SQL Units: `4`
- Acceptance: pass `3`, fail `0`, need params `1`
- Delivery: patches `0`, applicable `0`
- Failures: fatal `0`, retryable `0`, degradable `1`
- Phase Status: preflight `DONE`, scan `DONE`, optimize `DONE`, validate `DONE`, patch_generate `DONE`, report `DONE`
