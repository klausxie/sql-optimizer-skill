# SQL 优化报告：run_ed557b816d39

## 执行决策
- 发布就绪度：`CONDITIONAL_GO`
- 优化结论：`PARTIAL`
- 证据置信度：`MEDIUM`
- 范围：SQL 单元 `4`, 优化建议 `4`
- 交付快照：补丁 `3`, 可应用 `3`, 阻塞 SQL `1`
- 性能证据：改进 `0`, 未改进 `0`
- 验证状态：已验证 `14`, 部分 `2`, 未验证 `0`
- 物化模式：`{'STATEMENT_TEMPLATE_SAFE': 1, 'STATEMENT_SQL': 2}`
- 物化原因：`{'STATEMENT_INCLUDE_SAFE': 1, 'STATIC_STATEMENT': 2}`
- 物化操作：`{'PATCH_READY': 3}`

## 优先处理的 SQL
| SQL 键 | 优先级 | 可操作性 | 交付状态 | 补丁可应用 | 当前原因 | 摘要 |
|---|---|---|---|---|---|---|
| `demo.user.listUsersSorted#v3` | `P0` | `HIGH` | `READY_TO_APPLY` | `true` | 这是最快的安全收益，因为补丁已就绪 | patch is ready to apply |
| `demo.user.findUsersByStatusRecent#v4` | `P0` | `LOW` | `READY_TO_APPLY` | `true` | 这是最快的安全收益，因为补丁已就绪 | patch is ready to apply |
| `demo.user.listUsers#v1` | `P0` | `LOW` | `READY_TO_APPLY` | `true` | 这是最快的安全收益，因为补丁已就绪 | patch is ready to apply |
| `demo.user.findUsers#v2` | `P2` | `BLOCKED` | `BLOCKED` | `n/a` | 当前置信度低于领先候选 | automatic patch generation is blocked by current mapper or candidate shape |

## 主要风险
- `VALIDATE_SECURITY_DOLLAR_SUBSTITUTION` (`degradable`): 数量 `1`, 影响 SQL `1`

## 交付状态
- preflight: `DONE`
- scan: `DONE` (尝试 `1`)
- optimize: `DONE` (尝试 `4`)
- validate: `DONE` (尝试 `4`)
- patch_generate: `DONE` (尝试 `4`)
- report: `DONE`

## 变更组合
| SQL 键 | 状态 | 来源 | 性能 | 物化 | 补丁可应用 | 补丁决策 |
|---|---|---|---|---|---|---|
| `demo.user.listUsers#v1` | `PASS` | `llm` | `未知` | `STATEMENT_TEMPLATE_SAFE` | `true` | `PATCH_SELECTED_SINGLE_PASS` |
| `demo.user.findUsers#v2` | `NEED_MORE_PARAMS` | `rule` | `未知` | `n/a` | `n/a` | `PATCH_CONFLICT_NO_CLEAR_WINNER` |
| `demo.user.listUsersSorted#v3` | `PASS` | `rule` | `未知` | `STATEMENT_SQL` | `true` | `PATCH_SELECTED_SINGLE_PASS` |
| `demo.user.findUsersByStatusRecent#v4` | `PASS` | `llm` | `未知` | `STATEMENT_SQL` | `true` | `PATCH_SELECTED_SINGLE_PASS` |

## 优化建议分析
| SQL 键 | 结论 | 问题 | LLM 候选 |
|---|---|---|---|
| `demo.user.listUsers#v1` | `NOOP` | `FULL_SCAN_RISK` | `3` |
| `demo.user.findUsers#v2` | `CAN_IMPROVE` | `DOLLAR_SUBSTITUTION,FULL_SCAN_RISK` | `0` |
| `demo.user.listUsersSorted#v3` | `CAN_IMPROVE` | `SELECT_STAR,FULL_SCAN_RISK` | `3` |
| `demo.user.findUsersByStatusRecent#v4` | `NOOP` | `无` | `3` |

## 技术证据
- `demo.user.listUsers#v1`: 行检查 `MATCH`, 成本 `None` -> `None`
  物化：`STATEMENT_TEMPLATE_SAFE` / `STATEMENT_INCLUDE_SAFE`
  证据：`/Users/klaus/Desktop/sql-optimizer-skill/tests/fixtures/project/runs/run_ed557b816d39/evidence/demo.user.listUsers#v1/candidate_2/equivalence.json`
- `demo.user.listUsersSorted#v3`: 行检查 `MATCH`, 成本 `None` -> `None`
  物化：`STATEMENT_SQL` / `STATIC_STATEMENT`
  证据：`/Users/klaus/Desktop/sql-optimizer-skill/tests/fixtures/project/runs/run_ed557b816d39/evidence/demo.user.listUsersSorted#v3/candidate_4/equivalence.json`
- `demo.user.findUsersByStatusRecent#v4`: 行检查 `MATCH`, 成本 `None` -> `None`
  物化：`STATEMENT_SQL` / `STATIC_STATEMENT`
  证据：`/Users/klaus/Desktop/sql-optimizer-skill/tests/fixtures/project/runs/run_ed557b816d39/evidence/demo.user.findUsersByStatusRecent#v4/candidate_1/equivalence.json`

## 行动计划（未来 24 小时）
- 后端：移除 ${} 动态 SQL: `rg -n "\$\{" src/main/resources/**/*.xml`
- 平台：恢复运行: `PYTHONPATH=python python3 scripts/sqlopt_cli.py resume --run-id run_ed557b816d39`

## 验证警告
- 无

## 验证覆盖
- 阶段覆盖：`{'scan': {'recorded': 4, 'expected': 4, 'ratio': 1.0}, 'optimize': {'recorded': 4, 'expected': 4, 'ratio': 1.0}, 'validate': {'recorded': 4, 'expected': 4, 'ratio': 1.0}, 'patch_generate': {'recorded': 4, 'expected': 4, 'ratio': 1.0}}`
- 主要差距：`[{'reason_code': 'OPTIMIZE_ANALYSIS_MISSING', 'count': 1}, {'reason_code': 'OPTIMIZE_ANALYSIS_PARTIAL', 'count': 1}, {'reason_code': 'PATCH_ACCEPTANCE_NOT_PASS', 'count': 1}, {'reason_code': 'RISKY_DOLLAR_SUBSTITUTION', 'count': 1}]`
- 阻塞 SQL: `[]`

## 附录
- report.json: `run_ed557b816d39/report.json`
- proposals: `run_ed557b816d39/proposals/optimization.proposals.jsonl`
- acceptance: `run_ed557b816d39/acceptance/acceptance.results.jsonl`
- patches: `run_ed557b816d39/patches/patch.results.jsonl`
- verification: `run_ed557b816d39/verification/ledger.jsonl`
- failures: `run_ed557b816d39/ops/failures.jsonl`
