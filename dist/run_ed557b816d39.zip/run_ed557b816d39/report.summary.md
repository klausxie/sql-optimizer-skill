# SQL 优化总结：run_ed557b816d39

- 优化结论：`PARTIAL`
- 发布就绪度：`CONDITIONAL_GO`
- 证据置信度：`MEDIUM`
- SQL 单元数：`4`
- 验证结果：通过 `3`, 失败 `0`, 需更多参数 `1`
- 交付物：补丁 `3`, 可应用 `3`
- 失败统计：致命 `0`, 可重试 `0`, 可降级 `1`
- 验证状态：已验证 `14`, 部分 `2`, 未验证 `0`

## 优先处理的 SQL
- demo.user.listUsersSorted#v3: 这是最快的安全收益，因为补丁已就绪 (P0, READY_TO_APPLY)
- demo.user.findUsersByStatusRecent#v4: 这是最快的安全收益，因为补丁已就绪 (P0, READY_TO_APPLY)
- demo.user.listUsers#v1: 这是最快的安全收益，因为补丁已就绪 (P0, READY_TO_APPLY)

- 阶段状态：preflight `DONE`, scan `DONE`, optimize `DONE`, validate `DONE`, patch_generate `DONE`, report `DONE`
