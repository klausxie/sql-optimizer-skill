# SQL 优化报告：run_601aa406a93c

## 执行决策
- 发布就绪度：`CONDITIONAL_GO`
- 优化结论：`PARTIAL`
- 证据置信度：`MEDIUM`
- 范围：SQL 单元 `3`, 优化建议 `3`
- 交付快照：补丁 `1`, 可应用 `1`, 阻塞 SQL `2`
- 性能证据：改进 `0`, 未改进 `0`
- 验证状态：已验证 `10`, 部分 `2`, 未验证 `0`
- 语义门：PASS `2`, FAIL `1`, UNCERTAIN `0`
- 置信度升级：`1` (`0.3333`), 来源 `{'DB_FINGERPRINT': 1}`
- 误拦截恢复：`1`, include 自动物化：`0`
- 策略恢复：wrapper collapse `1`, 策略分布 `{'SAFE_WRAPPER_COLLAPSE': 1}`
- 规范化：采用 `2`, 规则分布 `{'ALIAS_ONLY_CANONICAL_FORM': 1, 'COUNT_CANONICAL_FORM': 1}`
- 物化模式：`{'STATEMENT_TEMPLATE_SAFE': 1, 'STATEMENT_TEMPLATE_SAFE_WRAPPER_COLLAPSE': 1}`
- 物化原因：`{'STATEMENT_INCLUDE_SAFE': 1, 'WRAPPER_QUERY_COLLAPSE_SAFE': 1}`
- 物化操作：`{'PATCH_READY': 2}`

## 优先处理的 SQL
| SQL 键 | 优先级 | 可操作性 | 交付状态 | 主阻断 | 补丁可应用 | 当前原因 | 摘要 |
|---|---|---|---|---|---|---|---|
| `demo.user.countUser#v2` | `P0` | `LOW` | `READY_TO_APPLY` | `PATCH_SELECTED_SINGLE_PASS` | `true` | 这是最快的安全收益，因为补丁已就绪 | patch is ready to apply |
| `demo.user.listUsers#v1` | `P1` | `LOW` | `BLOCKED` | `SEMANTIC_GATE_FAIL` | `n/a` | 先消除语义门阻塞，再评估交付路径 | patch generation was blocked because semantic equivalence gate is not PASS |
| `demo.user.findUsers#v3` | `P1` | `BLOCKED` | `PATCHABLE_WITH_REWRITE` | `VALIDATE_SECURITY_DOLLAR_SUBSTITUTION` | `n/a` | 先移除 ${} 安全阻断，再恢复候选评估与补丁生成 | 检测到 ${} 动态 SQL，自动补丁被安全策略阻断 |

## 主要风险
- `VALIDATE_SEMANTIC_GATE_NOT_PASS` (`degradable`): 数量 `1`, 影响 SQL `1`
- `VALIDATE_SECURITY_DOLLAR_SUBSTITUTION` (`degradable`): 数量 `1`, 影响 SQL `1`

## 交付状态
- preflight: `DONE`
- scan: `DONE` (尝试 `1`)
- optimize: `DONE` (尝试 `3`)
- validate: `DONE` (尝试 `3`)
- patch_generate: `DONE` (尝试 `3`)
- report: `DONE`

## 变更组合
| SQL 键 | 状态 | 语义门 | 置信度 | 升级轨迹 | 未升级主因 | 阻断主因 | 来源 | 性能 | 物化 | 补丁可应用 | 补丁决策 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `demo.user.listUsers#v1` | `PASS` | `FAIL` | `HIGH` | `未升级` | `HARD_CONFLICT:SEMANTIC_PAGINATION_ADDED_OR_REMOVED` | `SEMANTIC_GATE_FAIL` | `llm` | `未知` | `STATEMENT_TEMPLATE_SAFE` | `n/a` | `PATCH_SEMANTIC_EQUIVALENCE_NOT_PASS` |
| `demo.user.countUser#v2` | `PASS` | `PASS` | `HIGH` | `MEDIUM->HIGH (DB_FINGERPRINT)` | `n/a` | `n/a` | `llm` | `未知` | `STATEMENT_TEMPLATE_SAFE_WRAPPER_COLLAPSE` | `true` | `PATCH_SELECTED_SINGLE_PASS` |
| `demo.user.findUsers#v3` | `NEED_MORE_PARAMS` | `UNKNOWN` | `UNKNOWN` | `未升级` | `DB_EVIDENCE_MISSING` | `VALIDATE_SECURITY_DOLLAR_SUBSTITUTION` | `rule` | `未知` | `n/a` | `n/a` | `PATCH_VALIDATION_BLOCKED_SECURITY` |

## 优化建议分析
| SQL 键 | 结论 | 问题 | LLM 候选 |
|---|---|---|---|
| `demo.user.listUsers#v1` | `NOOP` | `FULL_SCAN_RISK,NO_LIMIT` | `3` |
| `demo.user.countUser#v2` | `CAN_IMPROVE` | `FULL_SCAN_RISK,SUBQUERY_IN_FROM,NO_LIMIT` | `3` |
| `demo.user.findUsers#v3` | `CAN_IMPROVE` | `DOLLAR_SUBSTITUTION,FULL_SCAN_RISK,NO_LIMIT` | `0` |

## 技术证据
- `demo.user.listUsers#v1`: 行检查 `MATCH`, 成本 `None` -> `None`
  物化：`STATEMENT_TEMPLATE_SAFE` / `STATEMENT_INCLUDE_SAFE`
  语义门：`FAIL` / `HIGH`, 升级 `False`, 未升级主因 `HARD_CONFLICT:SEMANTIC_PAGINATION_ADDED_OR_REMOVED`
  证据：`/Users/klaus/Desktop/sql-optimizer-skill/tests/fixtures/project/runs/run_601aa406a93c/sql/demo_user_listUsers_v1/evidence/candidate_1/equivalence.json`
- `demo.user.countUser#v2`: 行检查 `MATCH`, 成本 `None` -> `None`
  物化：`STATEMENT_TEMPLATE_SAFE_WRAPPER_COLLAPSE` / `WRAPPER_QUERY_COLLAPSE_SAFE`
  语义门：`PASS` / `HIGH`, 升级 `True`, 未升级主因 `n/a`
  证据：`/Users/klaus/Desktop/sql-optimizer-skill/tests/fixtures/project/runs/run_601aa406a93c/sql/demo_user_countUser_v2/evidence/candidate_1/equivalence.json`

## 行动计划（未来 24 小时）
- 后端：移除 ${} 动态 SQL: `rg -n "\$\{" src/main/resources/**/*.xml`
- 平台：恢复运行: `PYTHONPATH=python python3 scripts/sqlopt_cli.py resume --run-id run_601aa406a93c`

## 验证警告
- 无

## 验证覆盖
- 阶段覆盖：`{'scan': {'recorded': 3, 'expected': 3, 'ratio': 1.0}, 'optimize': {'recorded': 3, 'expected': 3, 'ratio': 1.0}, 'validate': {'recorded': 3, 'expected': 3, 'ratio': 1.0}, 'patch_generate': {'recorded': 3, 'expected': 3, 'ratio': 1.0}}`
- 主要差距：`[{'reason_code': 'PATCH_ACCEPTANCE_NOT_PASS', 'count': 1}, {'reason_code': 'PATCH_SEMANTIC_EQUIVALENCE_NOT_PASS', 'count': 1}, {'reason_code': 'RISKY_DOLLAR_SUBSTITUTION', 'count': 1}, {'reason_code': 'VALIDATE_SEMANTIC_GATE_NOT_PASS', 'count': 1}]`
- 阻塞 SQL: `[]`

## 附录

- run index: `run_601aa406a93c/run.index.json`
- overview report: `run_601aa406a93c/overview/report.json`
- overview markdown: `run_601aa406a93c/overview/report.md`
- pipeline manifest: `run_601aa406a93c/pipeline/manifest.jsonl`
- sql catalog: `run_601aa406a93c/sql/catalog.jsonl`
- pipeline scan units: `run_601aa406a93c/pipeline/scan/sqlunits.jsonl`
- pipeline scan fragments: `run_601aa406a93c/pipeline/scan/fragments.jsonl`
- pipeline proposals: `run_601aa406a93c/pipeline/optimize/optimization.proposals.jsonl`
- pipeline acceptance: `run_601aa406a93c/pipeline/validate/acceptance.results.jsonl`
- pipeline patches: `run_601aa406a93c/pipeline/patch_generate/patch.results.jsonl`
- verification: `run_601aa406a93c/pipeline/verification/ledger.jsonl`
- failures: `run_601aa406a93c/pipeline/ops/failures.jsonl`
- sql outcomes: `run_601aa406a93c/diagnostics/sql_outcomes.jsonl`
- sql artifacts: `run_601aa406a93c/diagnostics/sql_artifacts.jsonl`
- blockers summary: `run_601aa406a93c/diagnostics/blockers.summary.json`
