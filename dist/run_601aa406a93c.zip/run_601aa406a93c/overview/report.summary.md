# SQL 优化总结：run_601aa406a93c

- 优化结论：`PARTIAL`
- 发布就绪度：`CONDITIONAL_GO`
- 证据置信度：`MEDIUM`
- SQL 单元数：`3`
- 验证结果：通过 `2`, 失败 `0`, 需更多参数 `1`
- 交付物：补丁 `1`, 可应用 `1`
- 失败统计：致命 `0`, 可重试 `0`, 可降级 `2`
- 验证状态：已验证 `10`, 部分 `2`, 未验证 `0`
- 语义门：PASS `2`, FAIL `1`, UNCERTAIN `0`
- 置信度升级：`1` (`0.3333`), 来源 `{'DB_FINGERPRINT': 1}`
- 误拦截恢复：`1`, include 自动物化：`0`
- 策略恢复：wrapper collapse `1`, 策略分布 `{'SAFE_WRAPPER_COLLAPSE': 1}`
- 规范化：采用 `2`, 规则分布 `{'ALIAS_ONLY_CANONICAL_FORM': 1, 'COUNT_CANONICAL_FORM': 1}`

## 优先处理的 SQL
- demo.user.countUser#v2: 这是最快的安全收益，因为补丁已就绪 (P0, READY_TO_APPLY)
- demo.user.listUsers#v1: 先消除语义门阻塞，再评估交付路径 (P1, BLOCKED)
- demo.user.findUsers#v3: 先移除 ${} 安全阻断，再恢复候选评估与补丁生成 (P1, PATCHABLE_WITH_REWRITE)

- 阶段状态：preflight `DONE`, scan `DONE`, optimize `DONE`, validate `DONE`, patch_generate `DONE`, report `DONE`
