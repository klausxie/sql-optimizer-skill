from __future__ import annotations

import glob
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from ..manifest import log_event
from ..subprocess_utils import run_capture_text


def _local_name(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[-1]
    return tag


def _is_mybatis_mapper_root(root: ET.Element) -> bool:
    return _local_name(str(root.tag)).lower() == "mapper" and bool(str(root.attrib.get("namespace") or "").strip())


def _build_unit(xml_path: Path, namespace: str, statement_id: str, statement_type: str, sql: str, idx: int) -> dict[str, Any]:
    return {
        "sqlKey": f"{namespace}.{statement_id}#v{idx}",
        "xmlPath": str(xml_path),
        "namespace": namespace,
        "statementId": statement_id,
        "statementType": statement_type,
        "variantId": f"v{idx}",
        "sql": " ".join(sql.split()),
        "parameterMappings": [],
        "paramExample": {},
        "locators": {"statementId": statement_id},
        "riskFlags": ["DOLLAR_SUBSTITUTION"] if "${" in sql else [],
        "scanWarnings": None,
    }


def _python_fallback_scan(project_root: Path, mapper_globs: list[str], manifest_path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    units: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    files = []
    for pat in mapper_globs:
        files.extend(glob.glob(str(project_root / pat), recursive=True))
    if not files:
        warnings.append({"severity": "fatal", "reason_code": "SCAN_MAPPER_NOT_FOUND", "message": "no mapper files matched"})
        return [], warnings
    for fp in sorted(set(files)):
        path = Path(fp)
        try:
            root = ET.parse(path).getroot()
        except Exception as exc:
            warnings.append({
                "severity": "degradable",
                "reason_code": "SCAN_CLASS_RESOLUTION_DEGRADED",
                "message": f"xml parse degraded: {exc}",
                "xml_path": str(path),
            })
            log_event(manifest_path, "scan", "degraded", warnings[-1])
            continue
        if not _is_mybatis_mapper_root(root):
            continue
        namespace = root.attrib.get("namespace", "unknown")
        idx = 0
        for node in root.iter():
            tag = _local_name(str(node.tag)).lower()
            if tag not in {"select", "update", "delete", "insert"}:
                continue
            idx += 1
            statement_id = node.attrib.get("id", f"unknown_{idx}")
            sql = "".join(node.itertext()).strip()
            if not sql:
                continue
            units.append(_build_unit(path, namespace, statement_id, tag.upper(), sql, idx))
    return units, warnings


def _resolve_java_jar(project_root: Path, jar_path: str) -> Path:
    jar = Path(jar_path)
    if not jar.is_absolute():
        jar = (project_root / jar).resolve()
    return jar


def run_scan(config: dict[str, Any], run_dir: Path, manifest_path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    project_root = Path(config["project"]["root_path"]).resolve()
    mapper_globs = config["scan"]["mapper_globs"]
    dialect = str((config.get("db", {}) or {}).get("platform", "sql"))
    scan_cfg = config.get("scan", {}) or {}
    java_cfg = scan_cfg.get("java_scanner", {}) or {}
    class_resolution_cfg = scan_cfg.get("class_resolution", {}) or {}
    class_resolution_mode = str(class_resolution_cfg.get("mode", "tolerant")).strip().lower()
    jar_path = str(java_cfg.get("jar_path") or "").strip()
    out_path = run_dir / "scan.sqlunits.jsonl"

    if jar_path:
        jar = _resolve_java_jar(project_root, jar_path)
        if not jar.exists():
            return [], [
                {
                    "severity": "fatal",
                    "reason_code": "SCAN_UNKNOWN_EXIT",
                    "message": f"java scanner jar not found: {jar}",
                }
            ]
        scan_cfg_path = run_dir / "scan.config.json"
        scan_cfg_path.write_text(json.dumps(config.get("scan", {}), ensure_ascii=False), encoding="utf-8")
        cmd = [
            "java",
            "-jar",
            str(jar),
            "--project-root",
            str(project_root),
            "--config-path",
            str(scan_cfg_path),
            "--out-jsonl",
            str(out_path),
            "--dialect",
            dialect,
            "--run-id",
            run_dir.name,
        ]
        proc = run_capture_text(cmd)
        warnings = []
        if proc.stderr.strip():
            for line in proc.stderr.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except Exception:
                    payload = {"phase": "scan", "severity": "fatal", "reason_code": "SCAN_UNKNOWN_EXIT", "message": line}
                warnings.append(payload)
                log_event(manifest_path, "scan", "scanner_stderr", payload)
        if proc.returncode in (0, 10) and out_path.exists():
            units = []
            for line in out_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    units.append(json.loads(line))
            if units:
                if class_resolution_mode == "strict":
                    degrade_codes = {
                        "SCAN_CLASS_RESOLUTION_DEGRADED",
                        "SCAN_CLASS_NOT_FOUND",
                        "SCAN_TYPE_ATTR_SANITIZED",
                        "SCAN_STATEMENT_PARSE_DEGRADED",
                    }
                    if any(str(w.get("reason_code")) in degrade_codes for w in warnings):
                        return [], [
                            {
                                "severity": "fatal",
                                "reason_code": "SCAN_CLASS_RESOLUTION_DEGRADED",
                                "message": "class resolution degraded under strict mode",
                            }
                        ]
                return units, warnings
            warnings.append(
                {
                    "severity": "fatal",
                    "reason_code": "SCAN_XML_PARSE_FATAL",
                    "message": "java scan-agent produced no sql units",
                }
            )
            log_event(manifest_path, "scan", "failed", warnings[-1])
            return [], warnings
        warnings.append(
            {
                "severity": "fatal",
                "reason_code": "SCAN_UNKNOWN_EXIT",
                "message": f"java scan-agent exit={proc.returncode}",
            }
        )
        log_event(manifest_path, "scan", "failed", warnings[-1])
        return [], warnings

    return _python_fallback_scan(project_root, mapper_globs, manifest_path)
