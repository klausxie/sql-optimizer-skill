from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from ..constants import CONTRACT_VERSION
from ..contracts import ContractValidator
from ..failure_classification import classify_reason_code
from ..io_utils import read_json, read_jsonl, write_json, write_jsonl

_OPS_TOPOLOGY_STAGE_KEYS = ("scan", "optimize", "validate", "apply", "report")


def _read_jsonl_or_empty(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return read_jsonl(path)


def _read_json_or_default(path: Path, default: dict) -> dict:
    if not path.exists():
        return default
    row = read_json(path)
    return row if isinstance(row, dict) else default


def _compute_verdict(stats: dict) -> str:
    if int(stats.get("fatal_count") or 0) > 0:
        return "BLOCKED"
    if int(stats.get("acceptance_fail") or 0) > 0:
        return "ATTENTION"
    if int(stats.get("acceptance_need_more_params") or 0) > 0:
        return "PARTIAL"
    if int(stats.get("sql_units") or 0) == 0:
        return "EMPTY"
    return "PASS"


def _compute_release_readiness(verdict: str, stats: dict) -> str:
    if verdict in {"BLOCKED", "ATTENTION"}:
        return "NO_GO"
    if verdict == "PARTIAL":
        return "CONDITIONAL_GO"
    if verdict == "PASS" and int(stats.get("patch_applicable_count") or 0) > 0:
        return "GO"
    return "CONDITIONAL_GO"


def _filter_runtime_policy_for_ops_topology(runtime_cfg: dict) -> tuple[dict, dict]:
    timeout_src = dict(runtime_cfg.get("stage_timeout_ms") or {})
    retry_src = dict(runtime_cfg.get("stage_retry_max") or {})
    timeout = {k: int(timeout_src[k]) for k in _OPS_TOPOLOGY_STAGE_KEYS if k in timeout_src}
    retry = {k: int(retry_src[k]) for k in _OPS_TOPOLOGY_STAGE_KEYS if k in retry_src}
    return timeout, retry


def _default_next_actions(run_id: str, verdict: str, reason_counts: dict[str, int]) -> list[dict]:
    actions: list[dict] = []
    if verdict in {"BLOCKED", "ATTENTION", "PARTIAL"}:
        actions.append(
            {
                "action_id": "resume",
                "title": "Platform: resume run",
                "reason": "pipeline not fully healthy",
                "applicability": "pending or degraded pipeline",
                "expected_outcome": "continue or finalize processing",
                "commands": [f"PYTHONPATH=python python3 scripts/sqlopt_cli.py resume --run-id {run_id}"],
            }
        )
    if reason_counts.get("VALIDATE_DB_UNREACHABLE", 0) > 0:
        actions.append(
            {
                "action_id": "check-db",
                "title": "DBA: verify DB connectivity",
                "reason": "validation DB checks were skipped",
                "applicability": "VALIDATE_DB_UNREACHABLE present",
                "expected_outcome": "semantic and perf checks become executable",
                "commands": ['psql "$DSN" -c "select 1;"'],
            }
        )
    if reason_counts.get("VALIDATE_SECURITY_DOLLAR_SUBSTITUTION", 0) > 0:
        actions.append(
            {
                "action_id": "remove-dollar",
                "title": "Backend: remove ${} dynamic SQL",
                "reason": "unsafe SQL substitution blocks optimization",
                "applicability": "security warnings in validation",
                "expected_outcome": "statement becomes patchable",
                "commands": ['rg -n "\\$\\{" src/main/resources/**/*.xml'],
            }
        )
    if not actions:
        actions.append(
            {
                "action_id": "apply",
                "title": "Backend: apply generated patches",
                "reason": "run is healthy",
                "applicability": "applicable patches available",
                "expected_outcome": "land safe SQL improvements",
                "commands": [f"PYTHONPATH=python python3 scripts/sqlopt_cli.py apply --run-id {run_id}"],
            }
        )
    return actions


def _build_top_blockers(failures: list[dict], reason_counts: dict[str, int]) -> list[dict]:
    sql_keys_by_code: dict[str, set[str]] = {}
    for row in failures:
        code = str(row.get("reason_code") or "UNKNOWN")
        sql_key = str(row.get("sql_key") or "")
        sql_keys_by_code.setdefault(code, set())
        if sql_key:
            sql_keys_by_code[code].add(sql_key)
    out: list[dict] = []
    for code, count in sorted(reason_counts.items(), key=lambda kv: kv[1], reverse=True)[:3]:
        out.append(
            {
                "code": code,
                "count": int(count),
                "ratio": None,
                "severity": classify_reason_code(code, phase="validate"),
                "sql_keys": sorted(sql_keys_by_code.get(code, set())),
            }
        )
    return out


def _build_prioritized_sql_keys(failures: list[dict]) -> list[dict]:
    by_sql: dict[str, dict] = {}
    for row in failures:
        sql_key = str(row.get("sql_key") or "")
        if not sql_key:
            continue
        rcode = str(row.get("reason_code") or "UNKNOWN")
        bucket = by_sql.setdefault(sql_key, {"sql_key": sql_key, "count": 0, "blocker_codes": set(), "has_fatal": False})
        bucket["count"] += 1
        bucket["blocker_codes"].add(rcode)
        if str(row.get("classification") or "") == "fatal":
            bucket["has_fatal"] = True
    rows: list[dict] = []
    for val in by_sql.values():
        rows.append(
            {
                "sql_key": val["sql_key"],
                "priority": "P0" if val["has_fatal"] else "P1",
                "score": int(val["count"]),
                "blocker_codes": sorted(val["blocker_codes"]),
            }
        )
    rows.sort(key=lambda x: (0 if x["priority"] == "P0" else 1, -int(x["score"])))
    return rows[:10]


def _build_sql_rows(units: list[dict], acceptance: list[dict], patches: list[dict]) -> list[dict]:
    acceptance_by_sql_key = {str(row.get("sqlKey")): row for row in acceptance}
    patch_by_statement = {str(row.get("statementKey")): row for row in patches}
    rows: list[dict] = []
    for unit in units:
        sql_key = str(unit.get("sqlKey") or "")
        statement_key = sql_key.split("#", 1)[0]
        acceptance_row = acceptance_by_sql_key.get(sql_key, {})
        patch_row = patch_by_statement.get(statement_key, {})
        perf = acceptance_row.get("perfComparison") or {}
        eq = acceptance_row.get("equivalence") or {}
        rows.append(
            {
                "sql_key": sql_key,
                "status": acceptance_row.get("status") or "PENDING",
                "selected_source": acceptance_row.get("selectedCandidateSource") or "n/a",
                "semantic_risk": acceptance_row.get("semanticRisk") or "unknown",
                "perf_improved": perf.get("improved"),
                "before_cost": (perf.get("beforeSummary") or {}).get("totalCost"),
                "after_cost": (perf.get("afterSummary") or {}).get("totalCost"),
                "patch_applicable": patch_row.get("applicable"),
                "patch_selection_code": (patch_row.get("selectionReason") or {}).get("code"),
                "row_status": (eq.get("rowCount") or {}).get("status"),
                "evidence_refs": eq.get("evidenceRefs") or [],
            }
        )
    return rows


def _build_proposal_rows(proposals: list[dict]) -> list[dict]:
    rows: list[dict] = []
    for proposal in proposals:
        issues = proposal.get("issues") or []
        issue_codes = [str(x.get("code")) for x in issues if isinstance(x, dict) and x.get("code")]
        rows.append(
            {
                "sql_key": str(proposal.get("sqlKey") or ""),
                "verdict": str(proposal.get("verdict") or "UNKNOWN"),
                "issue_codes": issue_codes,
                "llm_candidate_count": len(proposal.get("llmCandidates") or []),
            }
        )
    return rows


def _render_summary_md(run_id: str, verdict: str, readiness: str, stats: dict, phase_status: dict[str, str]) -> str:
    return "\n".join(
        [
            f"# SQL Optimize Summary: {run_id}",
            "",
            f"- Verdict: `{verdict}`",
            f"- Release Readiness: `{readiness}`",
            f"- SQL Units: `{stats.get('sql_units', 0)}`",
            f"- Acceptance: pass `{stats.get('acceptance_pass', 0)}`, fail `{stats.get('acceptance_fail', 0)}`, need params `{stats.get('acceptance_need_more_params', 0)}`",
            f"- Delivery: patches `{stats.get('patch_files', 0)}`, applicable `{stats.get('patch_applicable_count', 0)}`",
            f"- Failures: fatal `{stats.get('fatal_count', 0)}`, retryable `{stats.get('retryable_count', 0)}`, degradable `{stats.get('degradable_count', 0)}`",
            f"- Phase Status: preflight `{phase_status.get('preflight', 'PENDING')}`, scan `{phase_status.get('scan', 'PENDING')}`, optimize `{phase_status.get('optimize', 'PENDING')}`, validate `{phase_status.get('validate', 'PENDING')}`, patch_generate `{phase_status.get('patch_generate', 'PENDING')}`, report `{phase_status.get('report', 'DONE')}`",
            "",
        ]
    )


def _render_report_md(
    run_id: str,
    verdict: str,
    readiness: str,
    stats: dict,
    phase_status: dict[str, str],
    attempts_by_phase: dict[str, int],
    next_actions: list[dict],
    top_blockers: list[dict],
    sql_rows: list[dict],
    proposal_rows: list[dict],
) -> str:
    lines = [
        f"# SQL Optimize Report: {run_id}",
        "",
        "## Executive Decision",
        f"- Release Readiness: `{readiness}`",
        f"- Verdict: `{verdict}`",
        f"- Scope: SQL units `{stats.get('sql_units', 0)}`, proposals `{stats.get('proposals', 0)}`",
        f"- Delivery Snapshot: patches `{stats.get('patch_files', 0)}`, applicable `{stats.get('patch_applicable_count', 0)}`, blocked sql `{stats.get('blocked_sql_count', 0)}`",
        f"- Perf Evidence: improved `{stats.get('perf_improved_count', 0)}`, not improved `{stats.get('perf_compared_but_not_improved_count', 0)}`",
        "",
        "## Top Risks",
    ]
    if top_blockers:
        for blocker in top_blockers:
            lines.append(
                f"- `{blocker.get('code')}` (`{blocker.get('severity')}`): count `{blocker.get('count')}`, impacted sql `{len(blocker.get('sql_keys') or [])}`"
            )
    else:
        lines.append("- None")

    lines.extend(
        [
            "",
            "## Delivery Status",
            f"- preflight: `{phase_status.get('preflight', 'PENDING')}`",
            f"- scan: `{phase_status.get('scan', 'PENDING')}` (attempts `{attempts_by_phase.get('scan', 0)}`)",
            f"- optimize: `{phase_status.get('optimize', 'PENDING')}` (attempts `{attempts_by_phase.get('optimize', 0)}`)",
            f"- validate: `{phase_status.get('validate', 'PENDING')}` (attempts `{attempts_by_phase.get('validate', 0)}`)",
            f"- patch_generate: `{phase_status.get('patch_generate', 'PENDING')}` (attempts `{attempts_by_phase.get('patch_generate', 0)}`)",
            f"- report: `{phase_status.get('report', 'DONE')}`",
            "",
            "## Change Portfolio",
            "| SQL Key | Status | Source | Perf | Patch Applicable | Patch Decision |",
            "|---|---|---|---|---|---|",
        ]
    )
    for row in sql_rows:
        perf_label = "improved" if row.get("perf_improved") is True else ("not-improved" if row.get("perf_improved") is False else "unknown")
        patch_app = row.get("patch_applicable")
        patch_label = "true" if patch_app is True else ("false" if patch_app is False else "n/a")
        lines.append(
            f"| `{row.get('sql_key')}` | `{row.get('status')}` | `{row.get('selected_source')}` | `{perf_label}` | `{patch_label}` | `{row.get('patch_selection_code') or 'n/a'}` |"
        )

    lines.extend(["", "## Proposal Insights", "| SQL Key | Verdict | Issues | LLM Candidates |", "|---|---|---|---|"])
    if proposal_rows:
        for row in proposal_rows:
            issues = ",".join(row.get("issue_codes") or []) or "none"
            lines.append(
                f"| `{row.get('sql_key')}` | `{row.get('verdict')}` | `{issues}` | `{row.get('llm_candidate_count')}` |"
            )
    else:
        lines.append("| `n/a` | `n/a` | `n/a` | `0` |")

    lines.extend(["", "## Technical Evidence"])
    pass_count = 0
    for row in sql_rows:
        if str(row.get("status")) != "PASS":
            continue
        pass_count += 1
        refs = row.get("evidence_refs") or []
        lines.append(
            f"- `{row.get('sql_key')}`: row-check `{row.get('row_status') or 'n/a'}`, cost `{row.get('before_cost')}` -> `{row.get('after_cost')}`"
        )
        lines.append(f"  evidence: `{refs[0]}`" if refs else "  evidence: `n/a`")
    if pass_count == 0:
        lines.append("- No PASS items with technical evidence.")

    lines.extend(["", "## Action Plan (Next 24h)"])
    if next_actions:
        for action in next_actions:
            cmd = (action.get("commands") or [""])[0]
            title = str(action.get("title") or action.get("action_id") or "action")
            lines.append(f"- {title}: `{cmd}`" if cmd else f"- {title}")
    else:
        lines.append("- None")

    lines.extend(
        [
            "",
            "## Appendix",
            f"- report.json: `{run_id}/report.json`",
            f"- proposals: `{run_id}/proposals/optimization.proposals.jsonl`",
            f"- acceptance: `{run_id}/acceptance/acceptance.results.jsonl`",
            f"- patches: `{run_id}/patches/patch.results.jsonl`",
            f"- failures: `{run_id}/ops/failures.jsonl`",
            "",
        ]
    )
    return "\n".join(lines)


def generate(run_id: str, mode: str, config: dict, run_dir: Path, validator: ContractValidator) -> dict:
    units = _read_jsonl_or_empty(run_dir / "scan.sqlunits.jsonl")
    proposals = _read_jsonl_or_empty(run_dir / "proposals" / "optimization.proposals.jsonl")
    acceptance = _read_jsonl_or_empty(run_dir / "acceptance" / "acceptance.results.jsonl")
    patches = _read_jsonl_or_empty(run_dir / "patches" / "patch.results.jsonl")
    state = _read_json_or_default(run_dir / "supervisor" / "state.json", {"phase_status": {}})
    phase_status = dict(state.get("phase_status") or {})
    attempts_by_phase = dict(state.get("attempts_by_phase") or {})

    llm_generated = sum(len(x.get("llmCandidates", []) or []) for x in proposals)
    llm_enabled = bool(config.get("llm", {}).get("enabled", False))
    llm_timeout_count = 0
    for proposal in proposals:
        for ref in proposal.get("llmTraceRefs") or []:
            trace_path = run_dir / ref
            if not trace_path.exists():
                continue
            row = read_json(trace_path)
            if row.get("degrade_reason") == "RUN_TIME_BUDGET_EXHAUSTED":
                llm_timeout_count += 1
            if row.get("response", {}).get("error_type") == "TimeoutError":
                llm_timeout_count += 1

    perf_improved_count = sum(1 for x in acceptance if x.get("status") == "PASS" and (x.get("perfComparison") or {}).get("improved") is True)
    perf_not_improved_count = sum(1 for x in acceptance if x.get("status") == "PASS" and (x.get("perfComparison") or {}).get("improved") is False)
    patch_file_count = sum(len(x.get("patchFiles", [])) for x in patches)
    patch_applicable_count = sum(1 for x in patches if x.get("applicable") is True)

    report = {
        "run_id": run_id,
        "mode": mode,
        "llm_gate": {"enabled": llm_enabled} if llm_enabled else None,
        "policy": config["policy"],
        "stats": {
            "sql_units": len(units),
            "proposals": len(proposals),
            "acceptance_pass": sum(1 for x in acceptance if x.get("status") == "PASS"),
            "pass_with_warn_count": sum(1 for x in acceptance if x.get("status") == "PASS" and (x.get("warnings") or [])),
            "acceptance_fail": sum(1 for x in acceptance if x.get("status") == "FAIL"),
            "acceptance_need_more_params": sum(1 for x in acceptance if x.get("status") == "NEED_MORE_PARAMS"),
            "semantic_error_count": sum(1 for x in acceptance if "VALIDATE_SEMANTIC_ERROR" in ((x.get("perfComparison") or {}).get("reasonCodes") or [])),
            "dollar_substitution_count": sum(1 for x in acceptance if "DOLLAR_SUBSTITUTION" in (x.get("riskFlags") or [])),
            "patch_files": patch_file_count,
            "patch_applicable_count": patch_applicable_count,
            "perf_improved_count": perf_improved_count,
            "perf_compared_but_not_improved_count": perf_not_improved_count,
            "blocked_sql_count": sum(1 for x in acceptance if x.get("status") != "PASS"),
            "db_unreachable_count": sum(1 for x in acceptance if "VALIDATE_DB_UNREACHABLE" in (x.get("perfComparison", {}).get("reasonCodes") or [])),
            "llm_candidates_generated": llm_generated,
            "llm_candidates_accepted": report_acceptance_llm_count(acceptance),
            "llm_candidates_rejected": max(llm_generated - report_acceptance_llm_count(acceptance), 0),
            "llm_timeout_count": llm_timeout_count,
            "preflight_failure_count": 0,
            "phase_reason_code_counts": {},
            "ineffective_reason_counts": {},
            "fatal_count": 0,
            "retryable_count": 0,
            "degradable_count": 0,
        },
        "items": {"units": units, "proposals": proposals, "acceptance": acceptance, "patches": patches},
        "summary": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "verdict": None,
            "release_readiness": None,
            "top_blockers": [],
            "next_actions": [],
            "prioritized_sql_keys": [],
        },
        "contract_version": CONTRACT_VERSION,
    }

    runtime_timeout, runtime_retry = _filter_runtime_policy_for_ops_topology(config["runtime"])
    topology = {
        "run_id": run_id,
        "executor": "python",
        "subagents": {"optimize": False, "validate": False},
        "llm_mode": "enabled" if llm_enabled else "disabled",
        "llm_gate": {"enabled": llm_enabled} if llm_enabled else None,
        "runtime_policy": {
            "resolved_from": "app_config.runtime",
            "stage_timeout_ms": runtime_timeout,
            "stage_retry_max": runtime_retry,
            "stage_retry_backoff_ms": config["runtime"]["stage_retry_backoff_ms"],
        },
    }
    validator.validate("ops_topology", topology)
    write_json(run_dir / "ops" / "topology.json", topology)

    failures = []
    for row in acceptance:
        if row.get("status") != "PASS":
            code = None
            feedback = row.get("feedback")
            if isinstance(feedback, dict):
                code = feedback.get("reason_code")
            classification = classify_reason_code(code, phase="validate")
            failures.append(
                {
                    "sql_key": row.get("sqlKey"),
                    "reason_code": code or "VALIDATE_PARAM_INSUFFICIENT",
                    "status": row.get("status"),
                    "classification": classification,
                    "phase": "validate",
                }
            )

    manifest_rows = _read_jsonl_or_empty(run_dir / "manifest.jsonl")
    for row in manifest_rows:
        if row.get("event") != "failed":
            continue
        payload = row.get("payload") or {}
        reason_code = payload.get("reason_code") or "RUNTIME_RETRY_EXHAUSTED"
        stage = row.get("stage")
        failures.append(
            {
                "sql_key": payload.get("statement_key"),
                "reason_code": reason_code,
                "classification": classify_reason_code(reason_code, phase=stage),
                "status": "FAILED",
                "phase": stage,
            }
        )

    report["stats"]["preflight_failure_count"] = sum(
        1 for row in manifest_rows if row.get("stage") == "preflight" and row.get("event") == "failed"
    )
    write_jsonl(run_dir / "ops" / "failures.jsonl", failures)

    reason_counts: dict[str, int] = {}
    phase_reason_counts: dict[str, dict[str, int]] = {}
    class_counts = {"fatal": 0, "retryable": 0, "degradable": 0}
    for row in failures:
        code = str(row.get("reason_code") or "UNKNOWN")
        reason_counts[code] = reason_counts.get(code, 0) + 1
        phase = str(row.get("phase") or "unknown")
        phase_bucket = phase_reason_counts.setdefault(phase, {})
        phase_bucket[code] = phase_bucket.get(code, 0) + 1
        cls = str(row.get("classification") or "fatal")
        class_counts[cls] = class_counts.get(cls, 0) + 1

    report["stats"]["ineffective_reason_counts"] = reason_counts
    report["stats"]["phase_reason_code_counts"] = phase_reason_counts
    report["stats"]["fatal_count"] = class_counts.get("fatal", 0)
    report["stats"]["retryable_count"] = class_counts.get("retryable", 0)
    report["stats"]["degradable_count"] = class_counts.get("degradable", 0)
    report["stats"]["pipeline_coverage"] = phase_status

    verdict = _compute_verdict(report["stats"])
    readiness = _compute_release_readiness(verdict, report["stats"])
    top_blockers = _build_top_blockers(failures, reason_counts)
    next_actions = _default_next_actions(run_id, verdict, reason_counts)
    prioritized_sql_keys = _build_prioritized_sql_keys(failures)

    report["summary"]["verdict"] = verdict
    report["summary"]["release_readiness"] = readiness
    report["summary"]["top_blockers"] = top_blockers
    report["summary"]["next_actions"] = next_actions
    report["summary"]["prioritized_sql_keys"] = prioritized_sql_keys

    sql_rows = _build_sql_rows(units, acceptance, patches)
    proposal_rows = _build_proposal_rows(proposals)

    validator.validate("run_report", report)
    write_json(run_dir / "report.json", report)
    (run_dir / "report.summary.md").write_text(
        _render_summary_md(run_id, verdict, readiness, report["stats"], phase_status),
        encoding="utf-8",
    )
    (run_dir / "report.md").write_text(
        _render_report_md(
            run_id,
            verdict,
            readiness,
            report["stats"],
            phase_status,
            attempts_by_phase,
            next_actions,
            top_blockers,
            sql_rows,
            proposal_rows,
        ),
        encoding="utf-8",
    )

    health = {
        "run_id": run_id,
        "mode": mode,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "ok",
        "failure_count": report["stats"]["acceptance_fail"],
        "fatal_failure_count": report["stats"]["fatal_count"],
        "retryable_failure_count": report["stats"]["retryable_count"],
        "degradable_count": report["stats"]["degradable_count"],
        "report_json": str(run_dir / "report.json"),
    }
    validator.validate("ops_health", health)
    write_json(run_dir / "ops" / "health.json", health)
    return report


def report_acceptance_llm_count(acceptance_rows: list[dict]) -> int:
    return sum(1 for row in acceptance_rows if (row.get("selectedCandidateSource") == "llm"))
