from __future__ import annotations

import difflib
import re
import subprocess
from pathlib import Path

from ..contracts import ContractValidator
from ..io_utils import append_jsonl, read_jsonl
from ..manifest import log_event


def _statement_key(sql_key: str) -> str:
    return sql_key.split("#", 1)[0]


def _render_sql_block(sql: str) -> str:
    lines = [line.strip() for line in str(sql).strip().splitlines() if line.strip()]
    if not lines:
        return "\n  "
    return "\n" + "\n".join(f"    {line}" for line in lines) + "\n  "


def _build_unified_patch(xml_path: Path, statement_id: str, statement_type: str, rewritten_sql: str) -> tuple[str | None, int]:
    original = xml_path.read_text(encoding="utf-8")
    tag = (statement_type or "select").strip().lower()
    # Match one mapper statement by id and replace its inner SQL block.
    pattern = re.compile(
        rf"(<{tag}\b[^>]*\bid=\"{re.escape(statement_id)}\"[^>]*>)([\s\S]*?)(</{tag}>)",
        flags=re.IGNORECASE,
    )
    m = pattern.search(original)
    if not m:
        return None, 0
    replaced = original[: m.start()] + m.group(1) + _render_sql_block(rewritten_sql) + m.group(3) + original[m.end() :]
    if replaced == original:
        return "", 0

    try:
        rel = xml_path.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except Exception:
        rel = xml_path.as_posix()
    old_lines = original.splitlines()
    new_lines = replaced.splitlines()
    diff_lines = list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{rel}",
            tofile=f"b/{rel}",
            lineterm="",
        )
    )
    patch_text = "".join(line + "\n" for line in diff_lines)
    changed = sum(1 for line in diff_lines if line.startswith("+") or line.startswith("-"))
    return patch_text, changed


def _check_patch_applicable(patch_file: Path, workdir: Path) -> tuple[bool, str | None]:
    try:
        proc = subprocess.run(
            ["git", "apply", "--check", str(patch_file)],
            cwd=workdir,
            capture_output=True,
            text=True,
            timeout=15,
        )
    except Exception as exc:
        return False, str(exc)
    if proc.returncode == 0:
        return True, None
    detail = (proc.stderr or proc.stdout or "git apply --check failed").strip()
    return False, detail


def execute_one(sql_unit: dict, acceptance: dict, run_dir: Path, validator: ContractValidator) -> dict:
    status = acceptance["status"]
    sql_key = sql_unit["sqlKey"]
    statement_key = _statement_key(sql_key)
    acceptance_rows = read_jsonl(run_dir / "acceptance" / "acceptance.results.jsonl")
    same_statement = [row for row in acceptance_rows if _statement_key(str(row.get("sqlKey", ""))) == statement_key]
    pass_rows = [row for row in same_statement if row.get("status") == "PASS"]
    locators = sql_unit.get("locators") or {}
    if not locators.get("statementId"):
        patch = {
            "sqlKey": sql_key,
            "statementKey": statement_key,
            "patchFiles": [],
            "diffSummary": {"skipped": True},
            "applyMode": "PATCH_ONLY",
            "rollback": "not_applied",
            "selectionReason": {"code": "PATCH_LOCATOR_AMBIGUOUS", "message": "missing statement locator"},
            "rejectedCandidates": [{"reason_code": "PATCH_LOCATOR_AMBIGUOUS"}],
            "candidatesEvaluated": len(same_statement) or 1,
        }
    elif status != "PASS":
        patch = {
            "sqlKey": sql_key,
            "statementKey": statement_key,
            "patchFiles": [],
            "diffSummary": {"skipped": True},
            "applyMode": "PATCH_ONLY",
            "rollback": "not_applied",
            "selectionReason": {"code": "PATCH_CONFLICT_NO_CLEAR_WINNER", "message": "non-pass acceptance"},
            "rejectedCandidates": [{"reason_code": "PATCH_CONFLICT_NO_CLEAR_WINNER"}],
            "candidatesEvaluated": len(same_statement) or 1,
        }
    elif len(pass_rows) != 1 or str(pass_rows[0].get("sqlKey")) != sql_key:
        patch = {
            "sqlKey": sql_key,
            "statementKey": statement_key,
            "patchFiles": [],
            "diffSummary": {"skipped": True},
            "applyMode": "PATCH_ONLY",
            "rollback": "not_applied",
            "selectionReason": {"code": "PATCH_CONFLICT_NO_CLEAR_WINNER", "message": "multiple pass variants or winner mismatch"},
            "rejectedCandidates": [{"reason_code": "PATCH_CONFLICT_NO_CLEAR_WINNER"}],
            "candidatesEvaluated": len(same_statement) or 1,
        }
    else:
        patch_file = run_dir / "patches" / f"{sql_key.replace('/', '_')}.patch"
        xml_path = Path(str(sql_unit.get("xmlPath") or ""))
        statement_id = str((locators.get("statementId") or sql_unit.get("statementId") or "")).strip()
        statement_type = str(sql_unit.get("statementType") or "select").strip().lower()
        original_sql = str(sql_unit.get("sql") or "")
        rewritten_sql = str(acceptance.get("rewrittenSql") or "").strip()
        if "#{" in original_sql and "?" in rewritten_sql and "#{" not in rewritten_sql:
            patch = {
                "sqlKey": sql_key,
                "statementKey": statement_key,
                "patchFiles": [],
                "diffSummary": {"skipped": True},
                "applyMode": "PATCH_ONLY",
                "rollback": "not_applied",
                "selectionReason": {"code": "PATCH_CONFLICT_NO_CLEAR_WINNER", "message": "placeholder semantics mismatch"},
                "rejectedCandidates": [{"reason_code": "PATCH_CONFLICT_NO_CLEAR_WINNER"}],
                "candidatesEvaluated": len(same_statement) or 1,
            }
        else:
            patch_text, changed_lines = _build_unified_patch(xml_path, statement_id, statement_type, rewritten_sql)
            if patch_text is None:
                patch = {
                    "sqlKey": sql_key,
                    "statementKey": statement_key,
                    "patchFiles": [],
                    "diffSummary": {"skipped": True},
                    "applyMode": "PATCH_ONLY",
                    "rollback": "not_applied",
                    "selectionReason": {"code": "PATCH_LOCATOR_AMBIGUOUS", "message": "statement not found in mapper"},
                    "rejectedCandidates": [{"reason_code": "PATCH_LOCATOR_AMBIGUOUS"}],
                    "candidatesEvaluated": len(same_statement) or 1,
                }
            else:
                patch_file.write_text(patch_text, encoding="utf-8")
                if changed_lines <= 0:
                    patch = {
                        "sqlKey": sql_key,
                        "statementKey": statement_key,
                        "patchFiles": [],
                        "diffSummary": {"skipped": True},
                        "applyMode": "PATCH_ONLY",
                        "rollback": "not_applied",
                        "selectionReason": {"code": "PATCH_NO_EFFECTIVE_CHANGE", "message": "rewritten sql has no diff"},
                        "rejectedCandidates": [{"reason_code": "PATCH_NO_EFFECTIVE_CHANGE"}],
                        "candidatesEvaluated": len(same_statement) or 1,
                        "applicable": None,
                        "applyCheckError": None,
                    }
                else:
                    applicable, apply_error = _check_patch_applicable(patch_file, Path.cwd().resolve())
                    if not applicable:
                        patch = {
                            "sqlKey": sql_key,
                            "statementKey": statement_key,
                            "patchFiles": [],
                            "diffSummary": {"skipped": True},
                            "applyMode": "PATCH_ONLY",
                            "rollback": "not_applied",
                            "selectedCandidateId": acceptance.get("selectedCandidateId"),
                            "candidatesEvaluated": len(same_statement) or 1,
                            "selectionReason": {"code": "PATCH_NOT_APPLICABLE", "message": "generated patch cannot apply"},
                            "rejectedCandidates": [{"reason_code": "PATCH_NOT_APPLICABLE"}],
                            "applicable": False,
                            "applyCheckError": apply_error,
                        }
                    else:
                        patch = {
                            "sqlKey": sql_key,
                            "statementKey": statement_key,
                            "patchFiles": [str(patch_file)],
                            "diffSummary": {"lines": changed_lines, "changed": bool(changed_lines)},
                            "applyMode": "PATCH_ONLY",
                            "rollback": "delete_patch_file",
                            "selectedCandidateId": acceptance.get("selectedCandidateId"),
                            "candidatesEvaluated": len(same_statement) or 1,
                            "selectionReason": {"code": "PATCH_SELECTED_SINGLE_PASS", "message": "single pass variant"},
                            "rejectedCandidates": [],
                            "applicable": True,
                            "applyCheckError": None,
                        }
    validator.validate("patch_result", patch)
    append_jsonl(run_dir / "patches" / "patch.results.jsonl", patch)
    log_event(run_dir / "manifest.jsonl", "patch_generate", "done", {"statement_key": sql_key})
    return patch
