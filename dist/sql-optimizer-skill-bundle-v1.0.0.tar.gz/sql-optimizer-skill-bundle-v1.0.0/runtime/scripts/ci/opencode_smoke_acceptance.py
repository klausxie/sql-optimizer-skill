#!/usr/bin/env python3
from __future__ import annotations

import ast
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _project_fixture(repo_root: Path) -> Path:
    return repo_root / "tests" / "fixtures" / "project"


def _scanner_jar(repo_root: Path) -> Path:
    return repo_root / "java" / "scan-agent" / "target" / "scan-agent-1.0.0.jar"


def _local_config_text(repo_root: Path) -> str:
    jar_path = _scanner_jar(repo_root).resolve()
    return "\n".join(
        [
            "project:",
            "  root_path: .",
            "",
            "scan:",
            "  mapper_globs:",
            "    - src/main/resources/**/*.xml",
            "  max_variants_per_statement: 3",
            "  java_scanner:",
            f"    jar_path: {jar_path}",
            "",
            "db:",
            "  platform: postgresql",
            "  dsn: postgresql://postgres:postgres@127.0.0.1:5432/postgres?sslmode=disable",
            "  schema: public",
            "",
            "validate:",
            "  db_reachable: false",
            "  validation_profile: balanced",
            "  allow_db_unreachable_fallback: true",
            "  plan_compare_enabled: false",
            "",
            "apply:",
            "  mode: PATCH_ONLY",
            "",
            "policy:",
            "  require_perf_improvement: false",
            "  cost_threshold_pct: 0",
            "  allow_seq_scan_if_rows_below: 0",
            "  semantic_strict_mode: true",
            "",
            "runtime:",
            "  profile: balanced",
            "  stage_timeout_ms:",
            "    preflight: 12000",
            "    scan: 180000",
            "    optimize: 600000",
            "    validate: 300000",
            "    apply: 120000",
            "    report: 60000",
            "  stage_retry_max:",
            "    scan: 1",
            "    optimize: 1",
            "    validate: 1",
            "    apply: 1",
            "    report: 1",
            "  stage_retry_backoff_ms: 1000",
            "",
            "llm:",
            "  enabled: true",
            "  provider: opencode_builtin",
            "  timeout_ms: 80000",
            "",
        ]
    )


def _strip_ansi(text: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", text)


def _parse_last_dict(text: str) -> dict[str, Any]:
    lines = [_strip_ansi(line).strip() for line in text.splitlines() if _strip_ansi(line).strip()]
    for line in reversed(lines):
        candidates = [line]
        start = line.find("{")
        end = line.rfind("}")
        if start != -1 and end != -1 and start < end:
            fragment = line[start : end + 1]
            if fragment != line:
                candidates.append(fragment)
        for candidate in candidates:
            try:
                value = ast.literal_eval(candidate)
            except Exception:
                try:
                    value = json.loads(candidate)
                except Exception:
                    continue
            if isinstance(value, dict):
                return value
    return {}


def _run(cmd: list[str], *, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)


def _require_ok(proc: subprocess.CompletedProcess[str], *, step: str) -> None:
    if proc.returncode == 0:
        return
    if proc.stdout.strip():
        print(proc.stdout.strip())
    if proc.stderr.strip():
        print(proc.stderr.strip(), file=sys.stderr)
    raise SystemExit(f"{step} failed with exit code {proc.returncode}")


def _verify_outputs(run_dir: Path) -> dict[str, Any]:
    state = json.loads((run_dir / "supervisor" / "state.json").read_text(encoding="utf-8"))
    report = json.loads((run_dir / "report.json").read_text(encoding="utf-8"))
    summary = (run_dir / "report.summary.md").read_text(encoding="utf-8")

    state_report = state["phase_status"]["report"]
    report_status = report["stats"]["pipeline_coverage"]["report"]
    summary_ok = "report `DONE`" in summary
    if state_report != "DONE" or report_status != "DONE" or not summary_ok:
        raise SystemExit(
            "smoke verification failed: expected report DONE in state.json, report.json, and report.summary.md"
        )

    return {
        "state_report": state_report,
        "report_json_report": report_status,
        "summary_has_report_done": summary_ok,
    }


def _latest_run_id(project_dir: Path) -> str:
    runs_dir = project_dir / "runs"
    if not runs_dir.exists():
        return ""
    candidates = [path for path in runs_dir.iterdir() if path.is_dir()]
    if not candidates:
        return ""
    latest = max(candidates, key=lambda path: path.stat().st_mtime)
    return latest.name


def _run_opencode_command(project_dir: Path, command: str, argument_text: str) -> dict[str, Any]:
    proc = _run(
        [
            "opencode",
            "run",
            "--dir",
            str(project_dir),
            "--command",
            command,
            argument_text,
        ]
    )
    _require_ok(proc, step=f"opencode {command}")
    return _parse_last_dict(proc.stdout)


def main() -> None:
    repo_root = _repo_root()
    fixture = _project_fixture(repo_root)
    if not fixture.exists():
        raise SystemExit(f"missing fixture project: {fixture}")
    if not _scanner_jar(repo_root).exists():
        raise SystemExit(f"missing scanner jar: {_scanner_jar(repo_root)}")

    with tempfile.TemporaryDirectory(prefix="sqlopt_opencode_accept_") as td:
        temp_root = Path(td)
        project_dir = temp_root / "project"
        shutil.copytree(fixture, project_dir)
        (project_dir / "sqlopt.local.yml").write_text(_local_config_text(repo_root), encoding="utf-8")

        install_proc = _run([sys.executable, str(repo_root / "install" / "install_skill.py"), "--project", str(project_dir), "--force"])
        _require_ok(install_proc, step="install_skill")

        run_payload = _run_opencode_command(
            project_dir,
            "sql-optimizer-run",
            "config=./sqlopt.local.yml to_stage=patch_generate max_steps=200 max_seconds=95",
        )
        run_id = str(run_payload.get("run_id") or "").strip() or _latest_run_id(project_dir)
        if not run_id:
            raise SystemExit("smoke verification failed: missing run_id from opencode run output")

        status_payload: dict[str, Any] = {}
        for _ in range(12):
            status_payload = _run_opencode_command(project_dir, "sql-optimizer-status", f"run_id={run_id} project=.")
            if str(status_payload.get("run_status")) == "COMPLETED":
                break
            if str(status_payload.get("run_status")) == "FAILED":
                raise SystemExit(f"smoke verification failed: run failed (run_id={run_id})")
            if bool(status_payload.get("complete")):
                break
            _run_opencode_command(project_dir, "sql-optimizer-resume", f"run_id={run_id} project=.")
        if str(status_payload.get("run_status")) != "COMPLETED":
            raise SystemExit(f"smoke verification failed: status not completed (run_id={run_id})")

        run_dir = project_dir / "runs" / run_id
        verification = _verify_outputs(run_dir)
        print(
            json.dumps(
                {
                    "ok": True,
                    "project_dir": str(project_dir),
                    "run_id": run_id,
                    "run_dir": str(run_dir),
                    "status": status_payload,
                    "verification": verification,
                },
                ensure_ascii=False,
            )
        )


if __name__ == "__main__":
    main()
