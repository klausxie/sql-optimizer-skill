package com.sqlopt.scan;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.session.Configuration;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class ScanAgentMain {
    private static final Pattern NAMESPACE_PATTERN =
            Pattern.compile("<mapper[^>]*namespace=\\\"([^\\\"]+)\\\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern STMT_PATTERN =
            Pattern.compile("<(select|update|delete|insert)[^>]*id=\\\"([^\\\"]+)\\\"[^>]*>[\\s\\S]*?</\\1>", Pattern.CASE_INSENSITIVE);
    private static final Pattern STMT_META_PATTERN =
            Pattern.compile("<(select|update|delete|insert)[^>]*id=\\\"([^\\\"]+)\\\"[^>]*>([\\s\\S]*?)</\\1>", Pattern.CASE_INSENSITIVE);
    private static final Pattern SQL_FRAGMENT_PATTERN =
            Pattern.compile("<sql\\b[\\s\\S]*?</sql>", Pattern.CASE_INSENSITIVE);
    private static final Pattern HASH_PLACEHOLDER_PATTERN =
            Pattern.compile("#\\{[^}]+\\}");

    private record ParseResult(List<String> rows, int discoveredCount, boolean degraded) {}

    private static class ScanConfig {
        final List<String> mapperGlobs;
        final String mode;
        final boolean enableClasspathProbe;
        final boolean enableTypeSanitize;
        final boolean statementLevelRecovery;

        ScanConfig(List<String> mapperGlobs, String mode, boolean enableClasspathProbe, boolean enableTypeSanitize, boolean statementLevelRecovery) {
            this.mapperGlobs = mapperGlobs;
            this.mode = mode;
            this.enableClasspathProbe = enableClasspathProbe;
            this.enableTypeSanitize = enableTypeSanitize;
            this.statementLevelRecovery = statementLevelRecovery;
        }
    }

    private static class MapperPieces {
        final String namespace;
        final List<String> fragments;
        final List<StatementPiece> statements;

        MapperPieces(String namespace, List<String> fragments, List<StatementPiece> statements) {
            this.namespace = namespace;
            this.fragments = fragments;
            this.statements = statements;
        }
    }

    private static class StatementPiece {
        final String id;
        final String xml;

        StatementPiece(String id, String xml) {
            this.id = id;
            this.xml = xml;
        }
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> argMap = parseArgs(args);
        String projectRoot = argMap.get("--project-root");
        String outJsonl = argMap.get("--out-jsonl");
        String configPath = argMap.get("--config-path");
        if (configPath == null && argMap.containsKey("--config")) {
            configPath = argMap.get("--config");
        }

        if (projectRoot == null || outJsonl == null || configPath == null) {
            emitError("fatal", "SCAN_UNKNOWN_EXIT", "missing required args", null, null, "missing --project-root/--out-jsonl/--config-path", null, false, null, null, null);
            System.exit(20);
        }

        ScanConfig scanConfig = loadScanConfig(Paths.get(configPath));
        Path root = Paths.get(projectRoot);
        List<Path> mapperFiles = findMapperXml(root, scanConfig.mapperGlobs);
        if (mapperFiles.isEmpty()) {
            emitError("fatal", "SCAN_MAPPER_NOT_FOUND", "no mapper xml found", null, null, null, null, false, null, null, null);
            System.exit(20);
        }

        URLClassLoader projectLoader = scanConfig.enableClasspathProbe ? buildProjectClassLoader(root) : null;
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        if (projectLoader != null) {
            Thread.currentThread().setContextClassLoader(projectLoader);
        }

        List<String> rows = new ArrayList<>();
        boolean degraded = false;
        int discoveredCount = 0;
        int parsedCount = 0;
        try {
            for (Path file : mapperFiles) {
                String xml = Files.readString(file, StandardCharsets.UTF_8);
                discoveredCount += countStatements(xml);
                String namespace = extractNamespace(xml);
                Map<String, StatementMeta> metaMap = parseStatementMeta(xml, namespace);

                ParseResult parsed = parseMapperWithRecovery(file, xml, namespace, metaMap, scanConfig);
                rows.addAll(parsed.rows());
                parsedCount += parsed.rows().size();
                if (parsed.degraded() || parsed.rows().size() < parsed.discoveredCount()) {
                    degraded = true;
                }
            }
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
            if (projectLoader != null) {
                try {
                    projectLoader.close();
                } catch (Exception ignore) {
                    // no-op
                }
            }
        }

        Path outPath = Paths.get(outJsonl);
        if (outPath.getParent() != null) {
            Files.createDirectories(outPath.getParent());
        }
        Files.write(outPath, rows, StandardCharsets.UTF_8);

        if (rows.isEmpty()) {
            emitError("fatal", "SCAN_XML_PARSE_FATAL", "no sql extracted", null, null, null, null, false, discoveredCount, parsedCount, ratio(discoveredCount, parsedCount));
            System.exit(20);
        }

        if (parsedCount < discoveredCount) {
            emitError(
                    "degradable",
                    "SCAN_STATEMENT_PARSE_DEGRADED",
                    "one or more statements could not be parsed",
                    null,
                    null,
                    null,
                    "summary",
                    false,
                    discoveredCount,
                    parsedCount,
                    ratio(discoveredCount, parsedCount)
            );
            degraded = true;
        }

        if ("strict".equals(scanConfig.mode) && degraded) {
            emitError("fatal", "SCAN_CLASS_RESOLUTION_DEGRADED", "strict mode rejects degraded scan", null, null, null, "strict_gate", false, discoveredCount, parsedCount, ratio(discoveredCount, parsedCount));
            System.exit(20);
        }

        System.exit(degraded ? 10 : 0);
    }

    private static ScanConfig loadScanConfig(Path configPath) {
        String text;
        try {
            text = Files.readString(configPath, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return defaultScanConfig();
        }
        List<String> mapperGlobs = parseMapperGlobs(text);
        if (mapperGlobs.isEmpty()) {
            mapperGlobs = List.of("**/*Mapper.xml", "**/*.xml");
        }
        String mode = parseStringValue(text, "mode", "tolerant").toLowerCase(Locale.ROOT);
        boolean enableClasspathProbe = parseBooleanValue(text, "enable_classpath_probe", true);
        boolean enableTypeSanitize = parseBooleanValue(text, "enable_type_sanitize", true);
        boolean statementLevelRecovery = parseBooleanValue(text, "statement_level_recovery", true);
        return new ScanConfig(mapperGlobs, mode, enableClasspathProbe, enableTypeSanitize, statementLevelRecovery);
    }

    private static ScanConfig defaultScanConfig() {
        return new ScanConfig(List.of("**/*Mapper.xml", "**/*.xml"), "tolerant", true, true, true);
    }

    private static List<String> parseMapperGlobs(String text) {
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("\"mapper_globs\"\\s*:\\s*\\[(.*?)\\]", Pattern.DOTALL).matcher(text);
        if (m.find()) {
            Matcher q = Pattern.compile("\"([^\"]+)\"").matcher(m.group(1));
            while (q.find()) {
                out.add(q.group(1));
            }
            return out;
        }

        String[] lines = text.split("\\r?\\n");
        boolean inMapperGlobs = false;
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("mapper_globs:")) {
                inMapperGlobs = true;
                continue;
            }
            if (inMapperGlobs) {
                if (trimmed.startsWith("-")) {
                    String v = trimmed.substring(1).trim();
                    if ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) {
                        v = v.substring(1, v.length() - 1);
                    }
                    if (!v.isBlank()) {
                        out.add(v);
                    }
                    continue;
                }
                if (!trimmed.isBlank() && !line.startsWith(" ") && !line.startsWith("\t")) {
                    break;
                }
            }
        }
        return out;
    }

    private static boolean parseBooleanValue(String text, String key, boolean defaultVal) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*(true|false)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (m.find()) {
            return Boolean.parseBoolean(m.group(1));
        }
        Matcher y = Pattern.compile("(?m)^\\s*" + Pattern.quote(key) + "\\s*:\\s*(true|false)\\s*$", Pattern.CASE_INSENSITIVE).matcher(text);
        if (y.find()) {
            return Boolean.parseBoolean(y.group(1));
        }
        return defaultVal;
    }

    private static String parseStringValue(String text, String key, String defaultVal) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"([^\"]+)\"").matcher(text);
        if (m.find()) {
            return m.group(1);
        }
        Matcher y = Pattern.compile("(?m)^\\s*" + Pattern.quote(key) + "\\s*:\\s*([A-Za-z0-9_\\-]+)\\s*$").matcher(text);
        if (y.find()) {
            return y.group(1);
        }
        return defaultVal;
    }

    private static ParseResult parseMapperWithRecovery(Path file, String xml, String namespace, Map<String, StatementMeta> metaMap, ScanConfig scanConfig) {
        List<String> out = new ArrayList<>();
        int discovered = countStatements(xml);
        try {
            out.addAll(parseMapperWithMyBatis(file, xml, metaMap));
            return new ParseResult(out, discovered, false);
        } catch (Exception e) {
            if (!isClassResolutionError(e)) {
                emitError("degradable", "SCAN_STATEMENT_PARSE_DEGRADED", e.getMessage(), file.toString(), null, e.getClass().getName(), "mapper_parse", false, null, null, null);
                return new ParseResult(out, discovered, true);
            }
            emitError("degradable", "SCAN_CLASS_NOT_FOUND", e.getMessage(), file.toString(), null, e.getClass().getName(), "mapper_parse", false, null, null, null);
        }

        if (scanConfig.enableTypeSanitize) {
            String sanitized = sanitizeTypeAttributes(xml);
            try {
                out.addAll(parseMapperWithMyBatis(file, sanitized, metaMap));
                emitError(
                        "degradable",
                        "SCAN_TYPE_ATTR_SANITIZED",
                        "mapper recovered by sanitizing type attributes",
                        file.toString(),
                        null,
                        null,
                        "type_sanitize",
                        true,
                        null,
                        null,
                        null
                );
                return new ParseResult(out, discovered, true);
            } catch (Exception e) {
                emitError("degradable", "SCAN_CLASS_RESOLUTION_DEGRADED", e.getMessage(), file.toString(), null, e.getClass().getName(), "type_sanitize", false, null, null, null);
            }
        }

        if (!scanConfig.statementLevelRecovery) {
            return new ParseResult(out, discovered, true);
        }

        boolean domRecovered = recoverByDom(file, xml, namespace, metaMap, out, scanConfig.enableTypeSanitize);
        if (domRecovered) {
            return new ParseResult(out, discovered, true);
        }

        recoverByRegex(file, xml, namespace, metaMap, out, scanConfig.enableTypeSanitize);
        return new ParseResult(out, discovered, true);
    }

    private static boolean recoverByDom(Path file, String xml, String namespace, Map<String, StatementMeta> metaMap, List<String> out, boolean enableTypeSanitize) {
        MapperPieces pieces;
        try {
            pieces = extractMapperPiecesByDom(xml);
        } catch (Exception e) {
            emitError("degradable", "SCAN_STATEMENT_PARSE_DEGRADED", e.getMessage(), file.toString(), null, e.getClass().getName(), "statement_split_dom", false, null, null, null);
            return false;
        }
        if (pieces.statements.isEmpty()) {
            return false;
        }
        Set<String> seen = new HashSet<>();
        for (StatementPiece piece : pieces.statements) {
            String stmtId = piece.id;
            if (stmtId != null && seen.contains(stmtId)) {
                continue;
            }
            if (stmtId != null) {
                seen.add(stmtId);
            }
            String candidateXml = buildSingleStatementMapper(namespace, pieces.fragments, piece.xml);
            String toParse = enableTypeSanitize ? sanitizeTypeAttributes(candidateXml) : candidateXml;
            try {
                out.addAll(parseMapperWithMyBatis(file, toParse, metaMap));
                emitError("degradable", "SCAN_TYPE_ATTR_SANITIZED", "statement recovered by dom split", file.toString(), stmtId, null, "statement_split_dom", true, null, null, null);
            } catch (Exception ex) {
                String reason = isClassResolutionError(ex) ? "SCAN_CLASS_NOT_FOUND" : "SCAN_STATEMENT_PARSE_DEGRADED";
                emitError("degradable", reason, ex.getMessage(), file.toString(), stmtId, ex.getClass().getName(), "statement_split_dom", false, null, null, null);
            }
        }
        return true;
    }

    private static void recoverByRegex(Path file, String xml, String namespace, Map<String, StatementMeta> metaMap, List<String> out, boolean enableTypeSanitize) {
        List<String> fragments = extractSqlFragments(xml);
        Matcher m = STMT_PATTERN.matcher(xml);
        while (m.find()) {
            String stmtXml = m.group(0);
            String statementId = extractStatementId(stmtXml);
            String candidateXml = buildSingleStatementMapper(namespace, fragments, stmtXml);
            String toParse = enableTypeSanitize ? sanitizeTypeAttributes(candidateXml) : candidateXml;
            try {
                out.addAll(parseMapperWithMyBatis(file, toParse, metaMap));
                emitError("degradable", "SCAN_TYPE_ATTR_SANITIZED", "statement recovered by regex split", file.toString(), statementId, null, "regex_fallback", true, null, null, null);
            } catch (Exception ex) {
                emitError("degradable", "SCAN_STATEMENT_PARSE_DEGRADED", ex.getMessage(), file.toString(), statementId, ex.getClass().getName(), "regex_fallback", false, null, null, null);
            }
        }
    }

    private static MapperPieces extractMapperPiecesByDom(String xml) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(false);
        disableUnsafeXmlFeatures(dbf);
        DocumentBuilder db = dbf.newDocumentBuilder();
        db.setEntityResolver((publicId, systemId) -> new InputSource(new StringReader("")));

        Document doc = db.parse(new InputSource(new StringReader(xml)));
        Element root = doc.getDocumentElement();
        String namespace = root.getAttribute("namespace");

        List<String> fragments = new ArrayList<>();
        List<StatementPiece> statements = new ArrayList<>();

        NodeList children = root.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }
            String name = node.getNodeName();
            if ("sql".equalsIgnoreCase(name)) {
                fragments.add(nodeToString(node));
                continue;
            }
            if ("select".equalsIgnoreCase(name)
                    || "update".equalsIgnoreCase(name)
                    || "delete".equalsIgnoreCase(name)
                    || "insert".equalsIgnoreCase(name)) {
                String id = ((Element) node).getAttribute("id");
                statements.add(new StatementPiece(id == null || id.isBlank() ? null : id, nodeToString(node)));
            }
        }
        return new MapperPieces(namespace == null || namespace.isBlank() ? "unknown" : namespace, fragments, statements);
    }

    private static void disableUnsafeXmlFeatures(DocumentBuilderFactory dbf) {
        try {
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false);
        } catch (Exception ignore) {
            // no-op
        }
        try {
            dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        } catch (Exception ignore) {
            // no-op
        }
        try {
            dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        } catch (Exception ignore) {
            // no-op
        }
        try {
            dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        } catch (Exception ignore) {
            // no-op
        }
    }

    private static String nodeToString(Node node) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        transformer.setOutputProperty(OutputKeys.INDENT, "no");
        java.io.StringWriter writer = new java.io.StringWriter();
        transformer.transform(new DOMSource(node), new StreamResult(writer));
        return writer.toString();
    }

    private static List<String> parseMapperWithMyBatis(Path file, String xml, Map<String, StatementMeta> metaMap) throws Exception {
        Configuration config = new Configuration();
        String resource = file.toString();
        try (InputStream in = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))) {
            XMLMapperBuilder parser = new XMLMapperBuilder(in, config, resource, config.getSqlFragments());
            parser.parse();
        }

        List<String> out = new ArrayList<>();
        Set<String> seenStatementIds = new HashSet<>();
        for (MappedStatement ms : config.getMappedStatements()) {
            if (!resource.equals(ms.getResource())) {
                continue;
            }
            String fullId = ms.getId();
            if (seenStatementIds.contains(fullId)) {
                continue;
            }
            seenStatementIds.add(fullId);
            StatementMeta meta = metaMap.getOrDefault(fullId, new StatementMeta("unknown", tail(fullId), false, null, List.of()));
            try {
                BoundSql boundSql = ms.getBoundSql(sampleParams());
                String normalizedSql = normalize(boundSql.getSql());
                normalizedSql = restoreHashPlaceholders(normalizedSql, meta);
                normalizedSql = restoreOrderByPlaceholder(normalizedSql, meta);
                if (normalizedSql.isBlank()) {
                    continue;
                }
                String riskFlags = meta.containsDollar ? "[\"DOLLAR_SUBSTITUTION\"]" : "[]";
                String parameterMappingsJson = buildParameterMappings(boundSql.getParameterMappings());
                String row = "{"
                        + "\"sqlKey\":\"" + esc(fullId + "#v1") + "\"," 
                        + "\"xmlPath\":\"" + esc(file.toString()) + "\"," 
                        + "\"namespace\":\"" + esc(meta.namespace) + "\"," 
                        + "\"statementId\":\"" + esc(meta.statementId) + "\"," 
                        + "\"statementType\":\"" + ms.getSqlCommandType().name() + "\"," 
                        + "\"variantId\":\"v1\"," 
                        + "\"sql\":\"" + esc(normalizedSql) + "\"," 
                        + "\"parameterMappings\":" + parameterMappingsJson + ","
                        + "\"paramExample\":{},"
                        + "\"locators\":{\"statementId\":\"" + esc(meta.statementId) + "\"},"
                        + "\"riskFlags\":" + riskFlags
                        + "}";
                out.add(row);
            } catch (Exception e) {
                String reason = isClassResolutionError(e) ? "SCAN_CLASS_NOT_FOUND" : "SCAN_STATEMENT_PARSE_DEGRADED";
                emitError("degradable", reason, e.getMessage(), file.toString(), meta.statementId, e.getClass().getName(), "bound_sql", false, null, null, null);
            }
        }
        return out;
    }

    private static URLClassLoader buildProjectClassLoader(Path projectRoot) throws Exception {
        List<URL> urls = new ArrayList<>();
        List<Path> candidates = List.of(
                projectRoot.resolve("target/classes"),
                projectRoot.resolve("target/test-classes"),
                projectRoot.resolve("build/classes/java/main"),
                projectRoot.resolve("build/classes/kotlin/main"),
                projectRoot.resolve("build/resources/main")
        );
        for (Path p : candidates) {
            if (Files.exists(p)) {
                urls.add(p.toUri().toURL());
            }
        }
        addGlobUrls(projectRoot.resolve("target/dependency"), "*.jar", urls);
        addGlobUrls(projectRoot.resolve("build/libs"), "*.jar", urls);
        return new URLClassLoader(urls.toArray(new URL[0]), Thread.currentThread().getContextClassLoader());
    }

    private static void addGlobUrls(Path dir, String glob, List<URL> urls) throws Exception {
        if (!Files.isDirectory(dir)) {
            return;
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, glob)) {
            for (Path p : stream) {
                urls.add(p.toUri().toURL());
            }
        }
    }

    private static String sanitizeTypeAttributes(String xml) {
        String out = xml;
        out = out.replaceAll("(?i)\\s+(resultType|parameterType|javaType|ofType|type)\\s*=\\s*\"[^\"]+\"", " $1=\"java.lang.Object\"");
        out = out.replaceAll("(?i)\\s+typeHandler\\s*=\\s*\"[^\"]+\"", "");
        out = out.replaceAll("(?i)\\s+resultMap\\s*=\\s*\"[^\"]+\"", "");
        return out;
    }

    private static boolean isClassResolutionError(Throwable t) {
        Throwable cur = t;
        while (cur != null) {
            String msg = String.valueOf(cur.getMessage()).toLowerCase(Locale.ROOT);
            if (msg.contains("classnotfoundexception")
                    || msg.contains("error resolving class")
                    || msg.contains("could not resolve type alias")
                    || msg.contains("cannot find class")) {
                return true;
            }
            cur = cur.getCause();
        }
        return false;
    }

    private static String buildSingleStatementMapper(String namespace, List<String> fragments, String stmtXml) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
        sb.append("<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n");
        sb.append("<mapper namespace=\"").append(escAttr(namespace)).append("\">\n");
        for (String frag : fragments) {
            sb.append(frag).append("\n");
        }
        sb.append(stmtXml).append("\n");
        sb.append("</mapper>");
        return sb.toString();
    }

    private static List<String> extractSqlFragments(String xml) {
        List<String> fragments = new ArrayList<>();
        Matcher m = SQL_FRAGMENT_PATTERN.matcher(xml);
        while (m.find()) {
            fragments.add(m.group(0));
        }
        return fragments;
    }

    private static String extractStatementId(String stmtXml) {
        Matcher m = Pattern.compile("id=\\\"([^\\\"]+)\\\"").matcher(stmtXml);
        return m.find() ? m.group(1) : null;
    }

    private static int countStatements(String xml) {
        Matcher m = STMT_META_PATTERN.matcher(xml);
        int count = 0;
        while (m.find()) {
            count++;
        }
        return count;
    }

    private static Map<String, Object> sampleParams() {
        Map<String, Object> params = new HashMap<>();
        params.put("id", 1);
        params.put("name", "demo");
        params.put("status", "ACTIVE");
        params.put("list", Arrays.asList(1, 2, 3));
        params.put("items", Arrays.asList("a", "b"));
        params.put("offset", 0);
        params.put("limit", 10);
        return params;
    }

    private static String buildParameterMappings(List<ParameterMapping> pms) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < pms.size(); i++) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append("{\"property\":\"").append(esc(pms.get(i).getProperty())).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String extractNamespace(String xml) {
        Matcher m = NAMESPACE_PATTERN.matcher(xml);
        return m.find() ? m.group(1) : "unknown";
    }

    private static Map<String, StatementMeta> parseStatementMeta(String xml, String namespace) {
        Map<String, StatementMeta> out = new HashMap<>();
        Matcher m = STMT_META_PATTERN.matcher(xml);
        while (m.find()) {
            String id = m.group(2);
            String body = m.group(3);
            boolean containsDollar = body != null && body.contains("${");
            String orderByDollarKey = null;
            List<String> hashPlaceholders = new ArrayList<>();
            if (body != null) {
                Matcher ob = Pattern.compile("(?i)\\border\\s+by\\s*\\$\\{([^}]+)\\}").matcher(body);
                if (ob.find()) {
                    orderByDollarKey = ob.group(1);
                }
                Matcher hp = HASH_PLACEHOLDER_PATTERN.matcher(body);
                while (hp.find()) {
                    hashPlaceholders.add(hp.group());
                }
            }
            out.put(namespace + "." + id, new StatementMeta(namespace, id, containsDollar, orderByDollarKey, hashPlaceholders));
        }
        return out;
    }

    private static List<Path> findMapperXml(Path root, List<String> mapperGlobs) throws Exception {
        List<PathMatcher> matchers = new ArrayList<>();
        for (String glob : mapperGlobs) {
            String normalized = glob.replace("\\\\", "/");
            matchers.add(FileSystems.getDefault().getPathMatcher("glob:" + normalized));
        }
        Set<Path> out = new LinkedHashSet<>();
        try (var walk = Files.walk(root)) {
            walk.filter(Files::isRegularFile)
                    .filter(p -> p.toString().endsWith(".xml"))
                    .forEach(
                            p -> {
                                Path rel = root.relativize(p);
                                String relNorm = rel.toString().replace("\\\\", "/");
                                Path relPath = Paths.get(relNorm);
                                for (PathMatcher matcher : matchers) {
                                    if (matcher.matches(relPath)) {
                                        out.add(p);
                                        break;
                                    }
                                }
                            }
                    );
        }
        return new ArrayList<>(out);
    }

    private static String normalize(String s) {
        return s == null ? "" : s.replaceAll("\\s+", " ").trim();
    }

    private static String restoreOrderByPlaceholder(String sql, StatementMeta meta) {
        if (sql == null || meta == null) {
            return sql;
        }
        if (sql.contains("${")) {
            return sql;
        }
        if (sql.matches("(?is).*\\border\\s+by\\s*$") && meta.containsDollar) {
            String key = (meta.orderByDollarKey == null || meta.orderByDollarKey.isBlank()) ? "orderBy" : meta.orderByDollarKey;
            return sql + " ${" + key + "}";
        }
        return sql;
    }

    private static String restoreHashPlaceholders(String sql, StatementMeta meta) {
        if (sql == null || meta == null || sql.contains("#{")) {
            return sql;
        }
        if (meta.hashPlaceholders == null || meta.hashPlaceholders.isEmpty() || sql.indexOf('?') < 0) {
            return sql;
        }
        int qCount = 0;
        for (int i = 0; i < sql.length(); i++) {
            if (sql.charAt(i) == '?') {
                qCount++;
            }
        }
        if (qCount != meta.hashPlaceholders.size()) {
            return sql;
        }
        StringBuilder out = new StringBuilder();
        int idx = 0;
        for (int i = 0; i < sql.length(); i++) {
            char ch = sql.charAt(i);
            if (ch == '?') {
                out.append(meta.hashPlaceholders.get(idx++));
            } else {
                out.append(ch);
            }
        }
        return out.toString();
    }

    private static String tail(String fullId) {
        int idx = fullId.lastIndexOf('.');
        return idx >= 0 ? fullId.substring(idx + 1) : fullId;
    }

    private static double ratio(int discoveredCount, int parsedCount) {
        if (discoveredCount <= 0) {
            return 1.0;
        }
        return (double) parsedCount / (double) discoveredCount;
    }

    private static void emitError(
            String severity,
            String reasonCode,
            String message,
            String xmlPath,
            String statementId,
            String exception,
            String recoveryAction,
            boolean recovered,
            Integer discoveredCount,
            Integer parsedCount,
            Double successRatio
    ) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"phase\":\"scan\",\"severity\":\"").append(esc(severity)).append("\"");
        sb.append(",\"reason_code\":\"").append(esc(reasonCode)).append("\"");
        sb.append(",\"message\":\"").append(esc(message == null ? "" : message)).append("\"");
        if (xmlPath != null) {
            sb.append(",\"xml_path\":\"").append(esc(xmlPath)).append("\"");
            sb.append(",\"mapper_path\":\"").append(esc(xmlPath)).append("\"");
        }
        if (statementId != null) {
            sb.append(",\"statement_id\":\"").append(esc(statementId)).append("\"");
        }
        if (exception != null) {
            sb.append(",\"exception\":\"").append(esc(exception)).append("\"");
        }
        if (recoveryAction != null) {
            sb.append(",\"recovery_action\":\"").append(esc(recoveryAction)).append("\"");
            sb.append(",\"recovered\":").append(recovered ? "true" : "false");
        }
        if (discoveredCount != null) {
            sb.append(",\"discovered_count\":").append(discoveredCount);
        }
        if (parsedCount != null) {
            sb.append(",\"parsed_count\":").append(parsedCount);
        }
        if (successRatio != null) {
            sb.append(",\"success_ratio\":").append(String.format(Locale.ROOT, "%.6f", successRatio));
        }
        sb.append("}");
        System.err.println(sb);
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    private static String escAttr(String s) {
        return esc(s).replace("<", "&lt;").replace(">", "&gt;");
    }

    private static Map<String, String> parseArgs(String[] args) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i < args.length - 1; i += 2) {
            m.put(args[i], args[i + 1]);
        }
        return m;
    }

    private static class StatementMeta {
        final String namespace;
        final String statementId;
        final boolean containsDollar;
        final String orderByDollarKey;
        final List<String> hashPlaceholders;

        StatementMeta(String namespace, String statementId, boolean containsDollar, String orderByDollarKey, List<String> hashPlaceholders) {
            this.namespace = namespace;
            this.statementId = statementId;
            this.containsDollar = containsDollar;
            this.orderByDollarKey = orderByDollarKey;
            this.hashPlaceholders = hashPlaceholders == null ? List.of() : List.copyOf(hashPlaceholders);
        }
    }
}
