#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


def _bootstrap() -> None:
    script_dir = Path(__file__).resolve().parent
    root_dir = script_dir.parent
    candidates = [root_dir / "python", root_dir / "runtime" / "python"]
    for path in candidates:
        if path.exists():
            sys.path.insert(0, str(path))
            return
    raise SystemExit("cannot locate python runtime (expected ./python or ./runtime/python)")


_bootstrap()

from sqlopt.install_support import cli_run_command, is_windows, skill_dir  # noqa: E402
from sqlopt.subprocess_utils import run_capture_text  # noqa: E402


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--project", default=".")
    return p.parse_args()


def _run_check(title: str, cmd: list[str]) -> bool:
    with tempfile.NamedTemporaryFile("w+", delete=False, encoding="utf-8") as tmp:
        out_path = Path(tmp.name)
    try:
        try:
            proc = run_capture_text(cmd)
        except (FileNotFoundError, OSError) as exc:
            print(f"[FAIL] {title}")
            print(str(exc))
            return False
        if proc.returncode == 0:
            print(f"[OK] {title}")
            return True
        print(f"[FAIL] {title}")
        out_path.write_text((proc.stdout or "") + ("\n" if proc.stdout else "") + (proc.stderr or ""), encoding="utf-8")
        print("\n".join(out_path.read_text(encoding="utf-8").splitlines()[:40]))
        return False
    finally:
        out_path.unlink(missing_ok=True)


def _make_run_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    return f"run_doctor_{stamp}_{uuid4().hex[:6]}"


def main() -> None:
    args = _parse_args()
    project_dir = Path(args.project).resolve()
    skill_root = skill_dir()
    cli = skill_root / "bin" / ("sqlopt-cli.cmd" if is_windows() else "sqlopt-cli")
    ok = True

    ok = _run_check("python available", [sys.executable, "--version"]) and ok
    ok = _run_check("opencode available", ["opencode", "--version"]) and ok
    if cli.exists():
        print("[OK] installed skill cli")
    else:
        print(f"[FAIL] installed skill cli\nmissing: {cli}")
        ok = False
    ok = _run_check("opencode ping", ["opencode", "run", "--format", "json", "--variant", "minimal", "ping"]) and ok

    config = project_dir / "sqlopt.yml"
    if config.exists() and cli.exists():
        run_id = _make_run_id()
        preflight_cmd = cli_run_command(cli, "run", "--config", str(config), "--run-id", run_id, "--to-stage", "preflight")
        ok = _run_check("preflight run", preflight_cmd) and ok
    else:
        print(f"[WARN] skip preflight: missing {config} or {cli}")

    if ok:
        print("doctor summary: PASS")
        raise SystemExit(0)
    if is_windows():
        print("hint: if opencode was just installed, reopen PowerShell to refresh PATH.")
    print("doctor summary: FAIL")
    raise SystemExit(1)


if __name__ == "__main__":
    main()
